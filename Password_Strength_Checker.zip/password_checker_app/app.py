"""
Password Strength Checker - Flask web app
Python (password_strength_checker.py) does the analysis,
templates/index.html is the frontend.

Run:  python app.py   then open http://127.0.0.1:5000
"""
from flask import Flask, jsonify, render_template, request

from password_strength_checker import analyze, classify, crack_time, generate_password

app = Flask(__name__)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/analyze")
def api_analyze():
    # The password is analysed in memory only: never stored or logged.
    password = (request.get_json(silent=True) or {}).get("password", "")
    if not password:
        return jsonify(empty=True)
    r = analyze(password)
    checks = dict(r["checks"], pattern=r["pattern_ok"])
    return jsonify(
        empty=False,
        score=r["score"],
        level=classify(r["score"]),
        entropy=r["entropy"],
        crack_time=crack_time(r["entropy"]),
        length=len(password),
        checks=checks,
        issues=r["issues"],
        tips=r["tips"],
    )


@app.get("/api/generate")
def api_generate():
    length = request.args.get("length", 16, type=int)
    length = max(12, min(length, 64))
    return jsonify(password=generate_password(length))


if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=5000)
