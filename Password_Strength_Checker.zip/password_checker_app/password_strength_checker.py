#!/usr/bin/env python3
"""
Password Strength Checker
-------------------------
Evaluates a password on length, lowercase, uppercase, digits and special
characters, detects weak patterns, classifies the result and gives clear
feedback on how to improve it.

Usage:
    python password_strength_checker.py            # interactive (hidden input)
    python password_strength_checker.py --show     # interactive (visible input)
    python password_strength_checker.py --generate # suggest a strong password
"""

import argparse
import getpass
import math
import re
import secrets
import string

COMMON_PASSWORDS = {
    "password", "123456", "12345678", "qwerty", "abc123", "letmein",
    "welcome", "admin", "iloveyou", "111111", "123123", "monkey",
    "football", "dragon", "master", "passw0rd", "trustno1", "000000",
    "1234567890",
}

SEQUENCE_PATTERN = re.compile(
    r"0123|1234|2345|3456|4567|5678|6789|abcd|bcde|cdef|qwerty|asdf",
    re.IGNORECASE,
)
REPEAT_PATTERN = re.compile(r"(.)\1{2,}")

LEVELS = ["Very Weak", "Weak", "Fair", "Strong", "Very Strong"]
GUESSES_PER_SECOND = 1e10  # offline attack with fast hardware


def analyze(password: str) -> dict:
    """Run all checks and return a result dictionary."""
    checks = {
        "length": len(password) >= 12,
        "lowercase": bool(re.search(r"[a-z]", password)),
        "uppercase": bool(re.search(r"[A-Z]", password)),
        "number": bool(re.search(r"[0-9]", password)),
        "special": bool(re.search(r"[^A-Za-z0-9]", password)),
    }

    issues = []   # serious problems
    tips = []     # improvement suggestions
    pattern_ok = True
    lowered = password.lower()

    if len(password) < 8:
        pattern_ok = False
        issues.append("Under 8 characters: very easy to brute-force.")
    if any(c in lowered for c in COMMON_PASSWORDS):
        pattern_ok = False
        issues.append("Contains a commonly leaked password.")
    if REPEAT_PATTERN.search(password):
        pattern_ok = False
        issues.append('Contains a repeated character run (e.g. "aaa").')
    if SEQUENCE_PATTERN.search(password):
        pattern_ok = False
        issues.append("Contains a sequential or keyboard pattern (e.g. 1234, qwerty).")

    if not checks["length"]:
        tips.append("Use at least 12 characters (longer is better).")
    if not checks["lowercase"]:
        tips.append("Add lowercase letters (a-z).")
    if not checks["uppercase"]:
        tips.append("Add uppercase letters (A-Z).")
    if not checks["number"]:
        tips.append("Add numbers (0-9).")
    if not checks["special"]:
        tips.append("Add special characters (e.g. ! @ # $ % &).")

    # Entropy estimate: length * log2(size of character pool)
    pool = 0
    if checks["lowercase"]:
        pool += 26
    if checks["uppercase"]:
        pool += 26
    if checks["number"]:
        pool += 10
    if checks["special"]:
        pool += 32
    entropy = round(len(password) * math.log2(pool)) if pool else 0

    # Score from 0 to 5
    score = 0
    score += len(password) >= 8
    score += len(password) >= 12
    score += checks["lowercase"] and checks["uppercase"]
    score += checks["number"]
    score += checks["special"]
    if not pattern_ok:
        score = max(0, score - 2)

    return {
        "checks": checks,
        "pattern_ok": pattern_ok,
        "issues": issues,
        "tips": tips,
        "entropy": entropy,
        "score": min(score, 5),
    }


def classify(score: int) -> str:
    return LEVELS[max(score - 1, 0)]


def crack_time(entropy_bits: int) -> str:
    """Human-readable estimate of time to brute-force the password."""
    if entropy_bits <= 0:
        return "instantly"
    seconds = (2 ** entropy_bits) / GUESSES_PER_SECOND
    if seconds < 1:
        return "instantly"
    units = [("seconds", 60), ("minutes", 60), ("hours", 24),
             ("days", 365), ("years", 100), ("centuries", None)]
    value = seconds
    for name, divisor in units:
        if divisor is None or value < divisor:
            if name == "centuries" and value > 1000:
                return "trillions of years"
            return f"{value:.1f} {name}" if value < 10 else f"{round(value)} {name}"
        value /= divisor
    return "a very long time"


def generate_password(length: int = 16) -> str:
    """Cryptographically secure random password with all character types."""
    lower = "abcdefghijkmnpqrstuvwxyz"
    upper = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    digits = "23456789"
    symbols = "!@#$%^&*-_=+?"
    allowed = lower + upper + digits + symbols
    chars = [secrets.choice(lower), secrets.choice(upper),
             secrets.choice(digits), secrets.choice(symbols)]
    chars += [secrets.choice(allowed) for _ in range(max(length, 12) - 4)]
    secrets.SystemRandom().shuffle(chars)
    return "".join(chars)


def report(password: str) -> None:
    if not password:
        print("No password entered.")
        return

    r = analyze(password)
    level = classify(r["score"])
    bar = "#" * r["score"] + "-" * (5 - r["score"])

    labels = {
        "length": "At least 12 characters",
        "lowercase": "Lowercase letter",
        "uppercase": "Uppercase letter",
        "number": "Number",
        "special": "Special character",
    }

    print("\n" + "=" * 46)
    print(f" Strength : {level}  [{bar}] {r['score']}/5")
    print(f" Entropy  : ~{r['entropy']} bits")
    print(f" Crack time (estimate): {crack_time(r['entropy'])}")
    print("=" * 46)
    print(" Checks:")
    for key, label in labels.items():
        print(f"   [{'x' if r['checks'][key] else ' '}] {label}")
    print(f"   [{'x' if r['pattern_ok'] else ' '}] No obvious pattern")

    if r["issues"]:
        print("\n Problems found:")
        for item in r["issues"]:
            print(f"   ! {item}")

    if r["tips"]:
        print("\n How to improve:")
        for item in r["tips"]:
            print(f"   - {item}")
    elif not r["issues"]:
        print("\n Great job! This password meets all the recommended criteria.")
    print()


def main() -> None:
    parser = argparse.ArgumentParser(description="Password Strength Checker")
    parser.add_argument("--show", action="store_true",
                        help="show the password while typing")
    parser.add_argument("--generate", action="store_true",
                        help="generate a strong password and evaluate it")
    args = parser.parse_args()

    if args.generate:
        pw = generate_password()
        print(f"Generated password: {pw}")
        report(pw)
        return

    print("Password Strength Checker (Ctrl+C to quit)")
    try:
        while True:
            prompt = "Enter a password: "
            pw = input(prompt) if args.show else getpass.getpass(prompt)
            report(pw)
            again = input("Check another? (y/n): ").strip().lower()
            if again != "y":
                break
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye.")


if __name__ == "__main__":
    main()
